1. Download the zip file and extract it.
2. after you extract open folder TicTacToe_Martinez twice
3. Open another TicTacToe folder and click the TicTacToe folder inside it
4. Find TicTacToe.sln
5. Open it
6. Run it.
7. You will redidect into the TicTacToe Game 2 players but using the same mouse and same page and if the game is over you can restart all over again but the score is keep on counting.
8. If you want to play against AI click the Play With AI on the given category and you will redirect inyo playing against AI and if you want to go back just click the Back button on the upper left corner on the web.
9. If you want to play Multiplayer just browse two different web or tab but same url and wait for the player1 and for the player2 to connect and enjoy have fun!
